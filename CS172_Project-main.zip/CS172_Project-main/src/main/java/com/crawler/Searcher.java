package com.crawler;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.crawler.springboot.Article;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.springframework.core.io.ClassPathResource;

public class Searcher {
	
	public static List<Article> search(String querystr) {
		try {
			String INDEX_DIR = ""; // directory contains the lucene indexes
			String seedPath = new ClassPathResource("seed.txt").getFile().getAbsolutePath();
			String parentPath = seedPath.replace("seed.txt", "");
			INDEX_DIR = parentPath+"indexFiles";

			//Create lucene searcher that searches over a single IndexReader
			Directory dir = FSDirectory.open(Paths.get(INDEX_DIR));
			IndexReader reader = DirectoryReader.open(dir);
			IndexSearcher searcher = new IndexSearcher(reader);

			//Query from user input. Default query is "lucene"
			//String inputQuery = "hello world";//String.join(" ", args);
			//String querystr = args.length > 0 ? inputQuery : "lucene";
			//String querystr = "hello world";
			
			if(querystr.length() < 0){
				querystr = "lucene";
			}
			QueryParser qp = new QueryParser("contents", new StandardAnalyzer());
			Query query = qp.parse(querystr);

			//Searches indexed contents using search term and returns the top 10 docs
			int hitsPerPage = 10;
			TopDocs foundDocs = searcher.search(query, hitsPerPage);
			ScoreDoc[] scoreDocs = foundDocs.scoreDocs;
			List<Article> articleList = new ArrayList<Article>();

			//Total # of documents found that matched the search term
			System.out.println("Query: " + querystr);
			System.out.println("Total Results: " + foundDocs.totalHits);

			//Print out file path, page url, and score of document
			for (int i = 0; i < scoreDocs.length; i++) {
				Document d = searcher.doc(scoreDocs[i].doc);
				String path = d.get("path");
				System.out.println((i+1) + ". File: " + path.substring(path.lastIndexOf('\\')+1, path.length()) +
						", Title: " + d.get("title") +
						", url: " + d.get("url") +
						", Content: " + d.get("contents").substring(0,250)+
						", Score: " + scoreDocs[i].score);
				// System.out.println(searcher.explain(query, scoreDocs[i].doc));
				articleList.add(new Article(d.get("url"),d.get("title"),(d.get("contents").substring(0,250)),"",scoreDocs[i].score));
			}

			// searcher.close(); // gives error undefined module
			reader.close();
			dir.close();

			return articleList;
		}
		catch (IOException e) {
			System.err.println("Error while searching index: " + e);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;

	}
}
