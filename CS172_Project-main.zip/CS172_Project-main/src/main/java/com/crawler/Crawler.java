package com.crawler;

import java.io.*;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.ArrayList;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URI;
import java.net.URLDecoder;


import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;


public class Crawler {
	public static Queue<Link> frontier = new LinkedList<>();
	public static HashSet<String> visited = new HashSet<>();

	public static int pageCounter = 0;
	public static int levelCounter = 0;
	public static int max_page_count = 0; 
	public static int max_level_count = 0; 
		
	public static void main(String[] args) {
		Link link;
		String filename = "";

		// take inputs
		if (args.length != 3) {
			System.err.println("Please enter 3 arguments: seed file name, number of pages to crawl, number of hops from seed.");
			System.exit(1);
		} 
		
		if (args[0].contains(".txt")) { // get seed urls file name
			filename = args[0].toString();
		} else {
			System.err.println("Input has to contain a text file.");
			System.exit(1);
		}

		try { // get max number of pages to crawl
			max_page_count = Integer.parseInt(args[1]);
		} catch (NumberFormatException e) {
			System.err.println("Argument" + args[1] + " must be an integer.");
			System.exit(1);
		}

		try { // get max number of pages to crawl
			max_level_count = Integer.parseInt(args[2]);
		} catch (NumberFormatException e) {
			System.err.println("Argument" + args[2] + " must be an integer.");
			System.exit(1);
		}

		// start crawling seed URLs
		try {
			File file = new File(filename);
			byte[] fileBytes = Files.readAllBytes(file.toPath());
			char singleChar;
			String url = "";
			for (byte b : fileBytes) {
				singleChar = (char) b; // convert from byte to string
				if (singleChar == '\n') { // finished getting one url
					System.out.println("SEED: " + url);
					if (url != "") {
						link = new Link(url, 0, "seed");
						crawl(link);
						url = ""; // empty url string to get new url
						link = null; 
					}					
				} else {
					url += singleChar;
				}
			}
		} catch (Exception e) { 
			System.err.println("Error: " + e); 
		}
	}

	private static void crawl(Link link) {
		//url: the url we want to visit
		//visited: keep track of the sites we already visited
		Link crawlUrl;
		Document doc; 

		frontier.add(link);
		visited.add(link.url);

		while (!frontier.isEmpty() && pageCounter < max_page_count) {
			crawlUrl = frontier.remove();

			if (checkApproval(crawlUrl.url)) { // checking if URL is approved to crawl using Robots.txt
				System.out.println("CRAWL URL AT LEVEL " + crawlUrl.level + ": " + crawlUrl.url.replace("\n","").replace("\r", "") + ". Queue size: " + frontier.size());
				doc = request(crawlUrl);

				pageCounter += 1;
				levelCounter = crawlUrl.level + 1;
				
				if (doc != null && levelCounter <= max_level_count) { //if doc is ok to visit, then...
					for (Element l : doc.select("a[href]")) { //select every single hyperlink in the seed document and visit them if unvisited
						String next_url = l.absUrl("href");
						boolean valid = isValidUrl(next_url);
						if (valid) { // only process url if valid
							next_url = encode(next_url);
							next_url = clean(next_url);
							next_url = normalize(next_url, crawlUrl.url);

							if (visited.contains(next_url) == false && next_url != "") { //checking if link was already visited (to avoid duplicates)
								Link next_link = new Link(next_url, levelCounter, crawlUrl.url); 
								frontier.add(next_link);
								visited.add(next_url);
								// System.out.println("NEXT: " + next_url);
							}
						}
					}
				}				
			} else {
				System.out.println("CRAWLING OF " + crawlUrl.url + " IS NOT ALLOWED.");
				continue;
			}
		}
	}

	// helper function: requests access to the link 
	private static Document request(Link link) {
		try { //catch error when it is unable to connect
			Connection con = Jsoup.connect(link.url); //connect to web page
			Document doc = con.get(); //retrieve page content; get() fetches and parses the HTML file
			
			if (con.response().statusCode() == 200) { //"statusCode()==200" verifies that the document that we requested for succeeded
				// System.out.println("Link: " + link.url + "\n");
				// System.out.println(doc.title() + "\n\n"); //web page's title
				downloadHtml(link, pageCounter);

				return doc;
			}
			return null; //unable to get document 
		}
		catch (IOException e) {
			return null; //unable to connect
		}
	}
	
	// download the HTML content of link and write to a file
	public static void downloadHtml(Link link, int pageCount) {
		try {
			Document doc = Jsoup.connect(link.url).get();
			String pc = Integer.toString(pageCount);
			String lc = Integer.toString(link.level);
			
			String fname = "src\\main\\java\\com\\crawler\\html_files\\File_no" + pc + "_level" + lc + ".txt"; 
			
			File file = new File(fname);
			
			if (!file.exists()) {
				FileWriter writer = new FileWriter(file);
				
				writer.write("--URL:-- " + link.url.replace("\n","").replace("\r", "") + '\n'); 
				writer.write("--Parent:-- " + link.parent.replace("\n","").replace("\r", "") + "\n");
				writer.write("--Title:-- " + doc.title() + '\n');
				writer.write("--Text content:-- " + doc.body().text() + '\n');
				
				writer.flush();
				writer.close();	
				
				return;
			}
		}
		catch (IOException e) {
			System.err.println("Error: " + e); 
		}
		return;
	}

	// check if url is valid
	public static boolean isValidUrl(String link) {
		if (!link.contains(".edu")) { //if link is not .edu, do not visit it.
			return false;
		}
		if (link.contains(".pdf") || link.contains(".png") || link.contains(".jpeg") || link.startsWith("mailto:")) { 
			return false;
		}
		//checks for websites that begin with anything other than http
		if (!link.contains("http") || link.contains("https")) {
			return false;
		}
		if (link.contains(".html")) { 
			return false;
		}

		return true;
	}

	// encode invalid characters in url
	public static String encode(String link){
		// System.out.println("Encoding: " + link);
		try {
			String decodedURL = URLDecoder.decode(link, "UTF-8");
			URL url = new URL(decodedURL);
			URI uri = new URI(url.getProtocol(), url.getUserInfo(), url.getHost(), url.getPort(), url.getPath(), url.getQuery(), url.getRef());
			String decodedURLAsString = uri.toASCIIString();
			return decodedURLAsString;
		}
		catch (Exception e) {
			return "";
		}
	}
	
	// clean url. return a cleaned string of the url
	public static String clean(String link) { 
		int lastPos = link.length();
		String newLink = link;

		// remove anything after "?" or "#"
		// indexOf returns -1 if "?" does not exist in string; otherwise, it returns the index of the 1st occurrence of the char "?"
		if (link.indexOf("?") > 0) { // remove query
			lastPos = link.indexOf("?");
		}
		if (link.indexOf("#") > 0) { // remove bookmark/anchor
			lastPos = link.indexOf("#");
		}
		
		newLink = link.substring(0, lastPos);
		
		// remove "/" and ":" at the end to avoid duplicates
		if (newLink.endsWith("/")){
			newLink = link.substring(0, lastPos - 1);
		}
		if (newLink.endsWith(":")){
			newLink = link.substring(0, lastPos - 1);
		}	

		return newLink;
	}

	// normalize relative url
	public static String normalize(String link, String crawlLink) { 
		URL url;
		String newLink = link.replace("\n","").replace("\r", "");
	
		if (newLink.startsWith("/")) { // path starts from foot of the host
			try { 
				url = new URL(crawlLink); 
				newLink = "http://" + url.getHost() + newLink;
			} catch(MalformedURLException exce){
				System.out.println("Invalid URL");
				return "";
			}
		} 
		else if (!newLink.startsWith("http")) { // path is relative to current path
			newLink = crawlLink.replace("\n","").replace("\r", "") + "/" + newLink;
		}

		return newLink;
	}

	// check robots.txt to see if we can crawl link
	public static boolean checkApproval(String url){
		URL pageUrl, robotUrl; //making new URL object for the page
		String robotCommands = "";
        
		try { 
			pageUrl = new URL(url); // checking for bad url
		} catch(MalformedURLException exce){
			System.out.println("Invalid URL");
			return false;
		}
		
		String host = pageUrl.getHost();
		String strRobot = "http://" + host + "/robots.txt";		
		//System.out.println(strRobot);
		try { 
			robotUrl = new URL(strRobot); // checking for bad url
		} catch(MalformedURLException exce){
			System.out.println("Invalid URL");
			return false;
		}
		
		try { // get content of robots.txt
			BufferedReader in = new BufferedReader(new InputStreamReader(robotUrl.openStream()));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				robotCommands += inputLine + "\n";
			}
			in.close();
			// System.out.println("ROBOT BEGIN: " + robotCommands + "ROBOT END");
		} catch(IOException exce){
			System.out.println("No Robots.txt file exists for webpage " + url + "\n");
			return true; // the case if there is no robots.txt file
		}

		//System.out.println(robotCommands);
		robotCommands = robotCommands.toLowerCase();
        	if (robotCommands.contains("disallow")) { // process links that are labeled DISALLOW
            		ArrayList<Robot> rules = new ArrayList<>();
			String[] lines = robotCommands.split("\n");
           		String userAgentTemp = null;
			
            		for (int i = 0; i < lines.length; i++){
                		String line = lines[i].trim();
                		if(line.toLowerCase().startsWith("user-agent")){ // getting the user agent val
                    			int start = line.indexOf(":") + 1;
                    			int end = line.length();
                    			userAgentTemp = line.substring(start, end).trim(); // getting rid of any spaces
                		}
               			 else if(line.startsWith("disallow")){
                    		 	if (userAgentTemp != null){
						Robot rob = new Robot();
						rob.userAgent = userAgentTemp;
						int start = line.indexOf(":") + 1;
						int end = line.length();
						rob.rule = line.substring(start,end).trim(); // getting rid of any spaces
						rules.add(rob);
                    			}
                		}
           		}

            		for (Robot robo : rules){
				String path = pageUrl.getPath();
                		if(robo.rule.length() == 0){		//allows all URLs
                   		//System.out.println("True"); 
				   return true;
                		}
               			else if(robo.rule == "/"){
                   		 //System.out.println("False"); //allows no URLs
					return false;
                		}
				else if (robo.rule.length() <= path.length()){
					String check = path.substring(0,robo.rule.length());
					if(check.equals(robo.rule)){
						//System.out.println("False");
						return false;
					}
				}
            		}
       	 	}
       	 //System.out.println("True");
		return true;
	}
}
