package com.crawler;

public class Link {
    public String url;
	public int level;
	public String parent;

    Link(){}
	Link(String url, int level, String parent) {
		this.url = url;
		this.level = level;
		this.parent = parent;
	}
}
