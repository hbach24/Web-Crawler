package com.crawler;

public class Robot {
    public String userAgent;
    public String rule;

    Robot(){}
}
