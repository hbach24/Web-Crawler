package com.crawler;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
// import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;

public class Indexer {
	//folder that stores all the converted indexes
	private static final String INDEX_DIR = "/Users/nishitha256/Desktop/CS172_Project/src/main/java/com/crawler/indexFiles";

	public static void main(String[] args) {
		//folder containing all downloaded txt files of each web page
		String docsPath = "/Users/nishitha256/Desktop/CS172_Project/src/main/java/com/crawler/html_files";
		//Input Path Variable
		final Path docDir = Paths.get(docsPath);

		try {
			//store index files in the index file system
			Directory dir = FSDirectory.open(Paths.get(INDEX_DIR));

			//holds all the configuration that's used to create an IndexWriter
			IndexWriterConfig iwc = new IndexWriterConfig(new StandardAnalyzer());
			//creates a new index. otherwise, if an index already exists, update it if needed (CREATE_OR_APPEND)
			iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);

			//create the writer object; once we have the writer object, we're ready to index all the docs/files
			IndexWriter writer = new IndexWriter(dir, iwc);
			indexDocs(writer, docDir);

			writer.close();
			dir.close();
		}
		catch (IOException e) {
			System.err.println("Error while indexing: " + e);
		}
	}

	//grabs every file in the html_files folder and calls indexDocument() on it
	static void indexDocs(final IndexWriter writer, Path path) throws IOException {
		if (Files.isDirectory(path)) { //checks if path is a directory
			//go through every text file within the directory and indexes each of them
			Files.walkFileTree(path, new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
					try {
						//System.out.println("****");
						//Index this file
						indexDoc(writer, file);
					}
					catch (IOException e) {
						System.err.println("Error while indexing: " + e);
					}
					return FileVisitResult.CONTINUE;
				}
			});
		}
		else { //path is a file. index this file
			indexDoc(writer, path);
		}
	}

	//creates the index for each document/file grabbed from indexDocs()
	static void indexDoc(IndexWriter writer, Path file) throws IOException {
		try (InputStream stream = Files.newInputStream(file)) {
			//Create lucene Document
			Document doc = new Document();
			String content = new String(Files.readAllBytes(file));

			//get url
			String extractURL = "";
			int indURL = content.indexOf("--URL:-- ");
			if (indURL != -1) {
				int indEndURL = content.indexOf(" ", indURL);
				extractURL = content.substring(indEndURL+1, content.indexOf("\n"));
			}

			//extracting text content
			int indTxt = content.indexOf("content:-- ");
			int indTitle = content.indexOf("--Title:-- ");

			//add doc to index
			String title = ""; String txtContent = "";
			if (indTxt != -1 && indTitle != -1) {
				//get title and text content
				int endIndTxt = content.indexOf(" ", indTxt);
				txtContent = content.substring(endIndTxt, content.length());
				int endIndTitle = content.indexOf(" ", indTitle);
				title = content.substring(endIndTitle+1, content.indexOf("\n", endIndTitle)).replace("\n","").replace("\r", "");

				//add SpringFields
				doc.add(new StringField("title", title, Field.Store.YES)); //url of the webpage in doc
				doc.add(new StringField("url", extractURL, Field.Store.YES)); //url of the webpage in doc
				doc.add(new StringField("path", file.toString(), Field.Store.YES)); //title of webpage 
				
				//add a TextField attribute for each document for storing its title AND text contents
				doc.add(new TextField("contents", title + " " + txtContent, Field.Store.YES));
				// System.out.println(extractURL);

				//update the document's index if already exists
				writer.updateDocument(new Term("path", file.toString()), doc);
			}
		}
		catch (IOException e) {
			System.err.println("Error while indexing: " + e);
		}
	}
}
