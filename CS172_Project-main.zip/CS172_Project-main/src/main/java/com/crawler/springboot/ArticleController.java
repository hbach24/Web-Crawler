package com.crawler.springboot;

import com.crawler.Searcher;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class ArticleController {
    static List<Article> articles;
    static {
        /*articles = new ArrayList<>();
        articles.add(new Article("First Article",
                "Class Overview, Overview of Information Retrieval and Search Engines","h","h"));
        articles.add(new Article("Second Article",
                "Ranking: Vector space model, Probabilistic Model, Language model","h","h"));
        articles.add(new Article( "Third Article",
                "Web Search: Spam, topic-specific pagerank","h","h"));*/
    }

    @GetMapping("/articles")
    public List<Article> searchArticles(
            @RequestParam(required=false, defaultValue="") String query) {
        if (query.isEmpty())
            query="lucene";
            //return articles;

        List<Article> articles = Searcher.search(query);

        List<Article> matches = new ArrayList<>();
        for (Article article : articles) {
            //if (article.body.contains(query))
                matches.add(article);
            }
        return matches;
    }
}
