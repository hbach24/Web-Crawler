package com.crawler.springboot;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDemoApplication {

    public static void main(String[] args) {

        //String parentPath = Crawler.crawl();
        //Indexer.indexFiles(parentPath);
        SpringApplication.run(SpringDemoApplication.class, args);
    }
}
