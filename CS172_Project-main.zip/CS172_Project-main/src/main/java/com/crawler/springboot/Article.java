package com.crawler.springboot;

public class Article {
    //public int id;
    public String title;
    public String body;
    public String url;
    public String parent;
    public float score;

    public Article(){}

    public Article(String url, String title, String body, String parent, float score) {
        this.url = url;
        //this.id = id;
        this.title = title;
        this.body = body;
        this.parent = parent;
        this.score = score;
    }

    /*public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }*/

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public float getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }



    @Override
    public String toString() {
        return String.format("Article[url=%s, parent=%s, title=%s, body=%s, score=%f]", url, parent, title, body, score);
    }
}
