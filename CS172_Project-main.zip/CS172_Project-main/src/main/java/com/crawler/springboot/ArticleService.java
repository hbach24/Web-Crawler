package com.crawler.springboot;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
// import org.apache.lucene.analysis.Analyzer;

//import sun.security.util.FilePaths;

@Service
public class ArticleService {
    //private static final String INDEX_DIR = "/Users/nishitha256/gs-spring-boot/initial/src/main/java/com/example/springboot/helper/indexFiles";

    //creates the index for each document/file grabbed from indexDocs()

    public List<String> searcher(String querystr){

        List<String> files = new ArrayList<String>();
        try {
            String INDEX_DIR = "";
            String seedPath = new ClassPathResource("seed.txt").getFile().getAbsolutePath();
            String parentPath = seedPath.replace("seed.txt", "");
            INDEX_DIR = parentPath+"indexFiles";

            //Create lucene searcher that searches over a single IndexReader
            Directory dir = FSDirectory.open(Paths.get(INDEX_DIR));
            System.out.println("*****"+dir.listAll());
            for(String st: dir.listAll()){
                System.out.println("st  "+st);
            }
            IndexReader reader = DirectoryReader.open(dir);
            IndexSearcher searcher = new IndexSearcher(reader);

            QueryParser qp = new QueryParser("contents", new StandardAnalyzer());
            Query query = qp.parse(querystr);

            //Searches indexed contents using search term and returns the top 10 docs
            int hitsPerPage = 10;
            TopDocs foundDocs = searcher.search(query, hitsPerPage);
            ScoreDoc[] scoreDocs = foundDocs.scoreDocs;

            //Total # of documents found that matched the search term
            System.out.println("Query: " + querystr);
            System.out.println("Total Results: " + foundDocs.totalHits);

            //Print out file path, page url, and score of document

            for (int i = 0; i < scoreDocs.length; i++) {
                Document d = searcher.doc(scoreDocs[i].doc);
                String path = d.get("path");

                System.out.println((i+1) + ". File: "+ path.substring(path.lastIndexOf('\\')+1, path.length()) + ", URL: " + d.get("url") + ", Score: " + scoreDocs[i].score);
                files.add(path.substring(path.lastIndexOf('\\')+1, path.length()));
                // System.out.println(searcher.explain(query, scoreDocs[i].doc));
            }

            // searcher.close(); // gives error undefined module
            reader.close();
            dir.close();
        }
        catch (Exception e){
            System.err.println("Error while searching index: " + e);
        }
        return files;
    }


}
